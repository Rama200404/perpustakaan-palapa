<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Versi</b> 1.1
    </div>
    <strong>Hak Cipta &copy; <?= date('Y'); ?>. Team</strong> Wawan Koswara | Repost by <a href='https://www.instagram.com/wawankoswara24/' title='www.instagram.com' target='_blank'>instagram</a>
    
</footer>